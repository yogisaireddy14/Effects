import "./styles.css";

function CssStyleSheet() {
  return (
    <>
      <div className="container">
        <h1>CSS Stylesheet Example</h1>
        <p>This is styled using a CSS stylesheet.</p>
      </div>
    </>
  );
}

export default CssStyleSheet;

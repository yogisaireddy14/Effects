import React from "react";

function Main() {
  return (
    <>
      <main className="main-body">
        <h2>Main Content</h2>
        <p>This is a react project</p>
      </main>
    </>
  );
}

export default Main;
